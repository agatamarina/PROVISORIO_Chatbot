import { FormEvent, useState } from "react"
import { cadastrarEdital } from "./services/api"
import type { CriarEditalInput, Edital, NoDecisao, OpcaoDecisao } from "./types/api"

type TextFieldKey = Exclude<keyof CriarEditalInput, "mensagem_inicial" | "arvore_decisao">

const editalFields: { key: TextFieldKey; label: string; multiline?: boolean }[] = [
  { key: "número", label: "Número do edital" },
  { key: "ano", label: "Ano" },
  { key: "setor", label: "Setor responsável" },
  { key: "título", label: "Título" },
  { key: "dados_gerais", label: "Dados gerais", multiline: true },
  { key: "cronograma", label: "Cronograma", multiline: true },
  { key: "cursos", label: "Cursos", multiline: true },
  { key: "requisitos", label: "Requisitos", multiline: true },
  { key: "vagas", label: "Vagas", multiline: true },
  { key: "disposicoes_iniciais", label: "Disposições iniciais", multiline: true },
  { key: "inscricoes", label: "Inscrições", multiline: true },
  { key: "seleção", label: "Critérios de seleção", multiline: true },
  { key: "comprovacao_reserva_vagas", label: "Comprovação de reserva de vagas", multiline: true },
  { key: "matricula", label: "Matrícula", multiline: true },
  { key: "disposicoes_finais", label: "Disposições finais", multiline: true },
]

function makeId() {
  return globalThis.crypto?.randomUUID?.() ?? `menu-${Date.now()}-${Math.random().toString(36).slice(2)}`
}

function createOption(titulo = "") : OpcaoDecisao {
  return {
    id: makeId(),
    titulo,
    entradas: [],
    resposta: "",
    submenu: null,
    voltarAoMenuPrincipal: false,
  }
}

function createMenu(mensagem = "") : NoDecisao {
  return { id: makeId(), mensagem, opcoes: [] }
}

function createInitialDraft(): CriarEditalInput {
  const cursosMenu = createMenu("O que quer saber sobre Cursos e editais? Responda:")
  cursosMenu.opcoes = [
    createOption("Quais cursos vão abrir em 2027"),
    createOption("Quais horários"),
    createOption("Vagas"),
    { ...createOption("Falar sobre outro assunto"), entradas: ["4", "voltar"], voltarAoMenuPrincipal: true },
  ]

  const menuInicial = createMenu("Sobre o que quer perguntar? Responda:")
  menuInicial.opcoes = [
    { ...createOption("Cursos e vagas"), entradas: ["1", "cursos", "cursos e vagas"], submenu: cursosMenu },
    { ...createOption("Prazos"), entradas: ["2", "prazos"] },
    { ...createOption("Requisitos"), entradas: ["3", "requisitos"] },
    { ...createOption("Reserva de vagas (cotas)"), entradas: ["4", "cotas", "reserva de vagas"] },
    {
      ...createOption("Não achei o que procurava"),
      entradas: ["5", "não achei", "outro assunto"],
      resposta: "Encaminhar para o Gemini ou informar o telefone do setor responsável.",
    },
  ]

  return {
    número: "",
    ano: "",
    setor: "",
    título: "",
    dados_gerais: "",
    cronograma: "",
    cursos: "",
    requisitos: "",
    vagas: "",
    disposicoes_iniciais: "",
    inscricoes: "",
    seleção: "",
    comprovacao_reserva_vagas: "",
    matricula: "",
    disposicoes_finais: "",
    mensagem_inicial: "Olá! Sou o assistente virtual. Como posso ajudar você?",
    arvore_decisao: menuInicial,
  }
}

function AddIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M12 5v14M5 12h14" /></svg>
}

function RemoveIcon() {
  return <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M5 12h14" /></svg>
}

function DecisionEditor({
  node,
  level,
  onChange,
}: {
  node: NoDecisao
  level: number
  onChange: (node: NoDecisao) => void
}) {
  function updateOption(id: string, update: (option: OpcaoDecisao) => OpcaoDecisao) {
    onChange({
      ...node,
      opcoes: node.opcoes.map((option) => option.id === id ? update(option) : option),
    })
  }

  function updateMenuMessage(mensagem: string) {
    onChange({ ...node, mensagem })
  }

  return (
    <fieldset className="decision-node" style={{ "--menu-level": level } as React.CSSProperties}>
      <legend>{level === 0 ? "Menu principal" : `Submenu ${level + 1}`}</legend>
      <label className="registration-field">
        <span>Mensagem exibida neste menu</span>
        <textarea
          onChange={(event) => updateMenuMessage(event.target.value)}
          placeholder="Ex.: Sobre o que quer perguntar? Responda:"
          required
          rows={2}
          value={node.mensagem}
        />
      </label>

      <div className="decision-options-heading">
        <span>Opções de resposta</span>
        <button
          className="text-action"
          onClick={() => onChange({ ...node, opcoes: [...node.opcoes, createOption(`Nova opção ${node.opcoes.length + 1}`)] })}
          type="button"
        >
          <AddIcon /> Adicionar opção
        </button>
      </div>

      {node.opcoes.length === 0 && (
        <p className="decision-empty">Adicione ao menos uma opção para este menu.</p>
      )}

      <div className="decision-options">
        {node.opcoes.map((option, index) => (
          <article className="decision-option" key={option.id}>
            <div className="decision-option-heading">
              <span className="decision-index">{String(index + 1).padStart(2, "0")}</span>
              <button
                aria-label={`Remover opção ${option.titulo || index + 1}`}
                className="icon-action"
                onClick={() => onChange({ ...node, opcoes: node.opcoes.filter((item) => item.id !== option.id) })}
                title="Remover opção"
                type="button"
              >
                <RemoveIcon />
              </button>
            </div>

            <label className="registration-field">
              <span>Texto da opção</span>
              <input
                onChange={(event) => updateOption(option.id, (current) => ({ ...current, titulo: event.target.value }))}
                placeholder="Ex.: Cursos e vagas"
                required
                value={option.titulo}
              />
            </label>
            <label className="registration-field">
              <span>Respostas aceitas, separadas por vírgula</span>
              <input
                onChange={(event) => updateOption(option.id, (current) => ({
                  ...current,
                  entradas: event.target.value.split(",").map((entry) => entry.trim()).filter(Boolean),
                }))}
                placeholder="Ex.: 1, cursos, cursos e vagas"
                value={option.entradas.join(", ")}
              />
            </label>
            <label className="registration-field">
              <span>Resposta automática (opcional se houver submenu)</span>
              <textarea
                onChange={(event) => updateOption(option.id, (current) => ({ ...current, resposta: event.target.value }))}
                placeholder="Mensagem enviada ao selecionar esta opção"
                rows={2}
                value={option.resposta}
              />
            </label>

            <label className="decision-return">
              <input
                checked={option.voltarAoMenuPrincipal}
                onChange={(event) => updateOption(option.id, (current) => ({
                  ...current,
                  voltarAoMenuPrincipal: event.target.checked,
                  submenu: event.target.checked ? null : current.submenu,
                }))}
                type="checkbox"
              />
              <span>Esta opção volta ao menu principal</span>
            </label>

            {!option.voltarAoMenuPrincipal && (
              <div className="submenu-controls">
                {option.submenu ? (
                  <>
                    <DecisionEditor
                      level={level + 1}
                      node={option.submenu}
                      onChange={(submenu) => updateOption(option.id, (current) => ({ ...current, submenu }))}
                    />
                    <button
                      className="text-action text-action--muted"
                      onClick={() => updateOption(option.id, (current) => ({ ...current, submenu: null }))}
                      type="button"
                    >
                      <RemoveIcon /> Remover submenu
                    </button>
                  </>
                ) : (
                  <button
                    className="text-action"
                    onClick={() => updateOption(option.id, (current) => ({ ...current, submenu: createMenu() }))}
                    type="button"
                  >
                    <AddIcon /> Criar submenu
                  </button>
                )}
              </div>
            )}
          </article>
        ))}
      </div>
    </fieldset>
  )
}

function menuIsIncomplete(node: NoDecisao): boolean {
  return !node.mensagem.trim() || node.opcoes.length === 0 || node.opcoes.some((option) =>
    !option.titulo.trim() ||
    (!option.resposta.trim() && !option.submenu && !option.voltarAoMenuPrincipal) ||
    (option.submenu !== null && menuIsIncomplete(option.submenu))
  )
}

export default function EditalRegistration({
  onBack,
  onCreated,
}: {
  onBack: () => void
  onCreated: (edital: Edital) => void
}) {
  const [draft, setDraft] = useState<CriarEditalInput>(createInitialDraft)
  const [isSaving, setIsSaving] = useState(false)
  const [feedback, setFeedback] = useState<{ type: "success" | "error"; message: string } | null>(null)

  async function handleSubmit(event: FormEvent<HTMLFormElement>) {
    event.preventDefault()
    setFeedback(null)

    if (menuIsIncomplete(draft.arvore_decisao)) {
      setFeedback({
        type: "error",
        message: "Complete cada menu: informe a mensagem, as opções e uma resposta, submenu ou retorno para cada opção.",
      })
      return
    }

    setIsSaving(true)
    try {
      const editalCriado = await cadastrarEdital(draft)
      onCreated(editalCriado)
      setFeedback({ type: "success", message: "Edital e fluxo de mensagens enviados para a API." })
    } catch (error) {
      setFeedback({
        type: "error",
        message: error instanceof Error ? error.message : "Não foi possível cadastrar o edital.",
      })
    } finally {
      setIsSaving(false)
    }
  }

  return (
    <main className="app-shell registration-shell">
      <div className="ambient ambient-one" />
      <div className="ambient ambient-two" />
      <section aria-label="Cadastro de edital" className="chat-app registration-app">
        <header className="registration-header">
          <div className="registration-brand">
            <IFBMark />
            <div>
              <span className="eyebrow">Administração</span>
              <h1>Cadastrar edital</h1>
            </div>
          </div>
          <button className="header-btn" onClick={onBack} type="button">
            Voltar à conversa
          </button>
        </header>

        <div className="registration-content">
          <form onSubmit={handleSubmit}>
            <section className="registration-section">
              <div className="registration-section-heading">
                <span>01</span>
                <div>
                  <h2>Dados do edital</h2>
                  <p>Preencha os campos que serão disponibilizados ao assistente.</p>
                </div>
              </div>
              <div className="editais-fields">
                {editalFields.map(({ key, label, multiline }) => (
                  <label className={`registration-field ${multiline ? "registration-field--wide" : ""}`} key={key}>
                    <span>{label}</span>
                    {multiline ? (
                      <textarea
                        onChange={(event) => setDraft((current) => ({ ...current, [key]: event.target.value }))}
                        required
                        rows={3}
                        value={draft[key]}
                      />
                    ) : (
                      <input
                        onChange={(event) => setDraft((current) => ({ ...current, [key]: event.target.value }))}
                        required
                        value={draft[key]}
                      />
                    )}
                  </label>
                ))}
              </div>
            </section>

            <section className="registration-section">
              <div className="registration-section-heading">
                <span>02</span>
                <div>
                  <h2>Mensagens e decisões</h2>
                  <p>Defina a saudação automática e organize as opções em menus e submenus.</p>
                </div>
              </div>
              <label className="registration-field registration-field--wide">
                <span>Mensagem inicial do assistente</span>
                <textarea
                  onChange={(event) => setDraft((current) => ({ ...current, mensagem_inicial: event.target.value }))}
                  required
                  rows={2}
                  value={draft.mensagem_inicial}
                />
              </label>
              <DecisionEditor
                level={0}
                node={draft.arvore_decisao}
                onChange={(arvore_decisao) => setDraft((current) => ({ ...current, arvore_decisao }))}
              />
            </section>

            {feedback && (
              <p className={`registration-feedback registration-feedback--${feedback.type}`} role="status">
                {feedback.message}
              </p>
            )}

            <div className="registration-actions">
              {feedback?.type === "success" ? (
                <button className="registration-submit" onClick={onBack} type="button">
                  Voltar à conversa
                </button>
              ) : (
                <button className="registration-submit" disabled={isSaving} type="submit">
                  {isSaving ? "Enviando para a API..." : "Salvar edital e mensagens"}
                </button>
              )}
            </div>
          </form>
        </div>
      </section>
    </main>
  )
}

function IFBMark() {
  return (
    <div aria-label="IFB" className="ifb-mark" role="img">
      <span className="ifb-dot" />
      {Array.from({ length: 8 }).map((_, index) => <span className="ifb-block" key={index} />)}
    </div>
  )
}